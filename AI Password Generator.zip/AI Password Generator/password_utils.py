import hashlib
import requests
import secrets
import string
import os
from openai import OpenAI

def check_pwned_api(password):
    """Check password against HaveIBeenPwned API (k-Anonymity)."""
    sha1password = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    first5_char, tail = sha1password[:5], sha1password[5:]
    try:
        response = requests.get(f'https://api.pwnedpasswords.com/range/{first5_char}', timeout=5)
        if response.status_code == 429:
            return -1 # Rate limited
        if response.status_code != 200:
            return None # Fail gracefully
        hashes = (line.split(':') for line in response.text.splitlines())
        for h, count in hashes:
            if h == tail:
                return int(count)
        return 0
    except Exception:
        return None

def generate_password_local(length, use_numbers, use_symbols):
    """Generate a cryptographically strong random password locally."""
    alphabet = string.ascii_letters
    if use_numbers:
        alphabet += string.digits
    if use_symbols:
        alphabet += "!@#$%^&*()_+-=[]{}|;:,.<>?"
        
    while True:
        password = ''.join(secrets.choice(alphabet) for _ in range(length))
        
        # Enforce constraints to ensure it's not a predictable pattern
        has_lower = any(c.islower() for c in password)
        has_upper = any(c.isupper() for c in password)
        has_number = any(c.isdigit() for c in password) if use_numbers else True
        has_symbol = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password) if use_symbols else True
        
        if has_lower and has_upper and has_number and has_symbol:
            return password

def generate_password(context, length, use_numbers, use_symbols):
    """
    Generate context-aware password using OpenAI API if available.
    Fallback to secure local generation if API key is missing.
    Returns: tuple (password, mode) where mode is 'ai' or 'local'.
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key and len(api_key.strip()) > 10:
        try:
            client = OpenAI(api_key=api_key)
            prompt = f"Generate an ultra-secure, highly entropic passphrase themed around: '{context}'. The string MUST be exactly {length} characters long. "
            if use_numbers: prompt += "Include numbers. "
            if use_symbols: prompt += "Include symbols. "
            prompt += "Return ONLY the raw passphrase string. No quotes, no markdown, no explanation."
            
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a specialized cryptographic payload generator. Output strictly the requested passphrase without any formatting."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=100,
                temperature=0.7,
            )
            return response.choices[0].message.content.strip(), 'ai'
        except Exception:
            # Fallback to local if API call fails
            return generate_password_local(length, use_numbers, use_symbols), 'local'
    else:
        # Fallback to local if no API key is configured
        return generate_password_local(length, use_numbers, use_symbols), 'local'
