import streamlit as st
import zxcvbn
import math
from dotenv import load_dotenv
import password_utils

# Load environment variables
load_dotenv()

# Configure page
st.set_page_config(
    page_title="PassGen | Context-Aware AI Security",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Initialize session state
if 'last_pwd' not in st.session_state:
    st.session_state.last_pwd = None
if 'last_mode' not in st.session_state:
    st.session_state.last_mode = None

# --- Premium Custom CSS ---
def apply_premium_css():
    st.markdown("""
    <style>
        /* Import premium typography */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap');
        
        /* Base Theme */
        .stApp {
            background: radial-gradient(120% 120% at 50% -20%, #1e1b4b 0%, #020617 60%, #000000 100%);
            color: #e2e8f0;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* Hide defaults */
        [data-testid="stHeader"] { display: none; }
        footer { display: none !important; }
        #MainMenu { display: none; }
        
        /* Font overrides */
        * { font-family: 'Plus Jakarta Sans', sans-serif !important; }
        code, pre, .password-box { font-family: 'Space Mono', monospace !important; }

        /* Top Navigation */
        .top-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem 3rem;
            background: rgba(2, 6, 23, 0.4);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            margin-top: -3rem;
            margin-bottom: 4rem;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        @media (max-width: 768px) {
            .top-nav { padding: 1rem; margin-bottom: 2rem; }
            .nav-links { display: none !important; }
        }
        .nav-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
            font-size: 1.2rem;
            letter-spacing: -0.02em;
            background: linear-gradient(to right, #ffffff, #a5b4fc);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .nav-brand svg { width: 22px; height: 22px; fill: #a5b4fc; }
        .nav-links {
            display: flex;
            gap: 2.5rem;
            font-size: 0.9rem;
            font-weight: 500;
            color: #94a3b8;
        }
        .nav-links span { cursor: pointer; transition: color 0.2s; }
        .nav-links span:hover { color: #ffffff; }

        /* Hero Section */
        .hero {
            text-align: center;
            max-width: 800px;
            margin: 0 auto 3.5rem auto;
            padding: 0 1rem;
        }
        .hero h1 {
            font-size: clamp(2.5rem, 5vw, 4rem);
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            background: linear-gradient(135deg, #ffffff 0%, #c7d2fe 50%, #818cf8 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: -0.03em;
        }
        .hero p {
            font-size: 1.15rem;
            color: #94a3b8;
            line-height: 1.6;
            margin-bottom: 2.5rem;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        .trust-badges {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .badge {
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(30, 41, 59, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.08);
            padding: 0.5rem 1rem;
            border-radius: 100px;
            font-size: 0.85rem;
            font-weight: 500;
            color: #cbd5e1;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.05);
        }
        
        /* Container styling (intercepting st.container border=True) */
        div[data-testid="stVerticalBlockBorderWrapper"] {
            background: rgba(15, 23, 42, 0.4) !important;
            backdrop-filter: blur(24px) !important;
            -webkit-backdrop-filter: blur(24px) !important;
            border-radius: 20px !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.05) !important;
            padding: 2.5rem !important;
        }
        
        div[data-testid="stVerticalBlockBorderWrapper"] h3 {
            font-size: 1.25rem !important;
            font-weight: 600 !important;
            color: #ffffff !important;
            margin-bottom: 1.5rem !important;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            padding-bottom: 1rem;
        }
        div[data-testid="stVerticalBlockBorderWrapper"] h4 {
            font-size: 1.1rem !important;
            font-weight: 600 !important;
            color: #ffffff !important;
            margin-bottom: 1rem !important;
            margin-top: 1.5rem !important;
        }

        /* Inputs */
        .stTextInput > div > div > input, .stNumberInput > div > div > input {
            background: rgba(2, 6, 23, 0.6) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            color: white !important;
            border-radius: 12px !important;
            padding: 0.8rem 1rem !important;
            font-size: 0.95rem !important;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.2) !important;
            transition: all 0.2s ease;
        }
        .stTextInput > div > div > input:focus {
            border-color: #6366f1 !important;
            box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2), inset 0 2px 4px rgba(0,0,0,0.2) !important;
        }
        
        /* Slider styling */
        .stSlider > div > div > div > div { background-color: #6366f1 !important; }
        .stSlider div[data-testid="stThumbValue"] { font-family: 'Space Mono', monospace !important; color: #a5b4fc !important; }

        /* Toggle Checkboxes */
        .stCheckbox > label > div[role="checkbox"] {
            background-color: rgba(30, 41, 59, 0.8) !important;
            border-color: rgba(255,255,255,0.2) !important;
            border-radius: 6px !important;
        }
        
        /* Primary Button */
        .stButton > button {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%) !important;
            color: white !important;
            border: 1px solid rgba(255,255,255,0.1) !important;
            border-radius: 12px !important;
            padding: 0.875rem 1.5rem !important;
            font-size: 1rem !important;
            font-weight: 600 !important;
            letter-spacing: 0.5px !important;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
            width: 100% !important;
            box-shadow: 0 8px 20px -4px rgba(99, 102, 241, 0.4), inset 0 1px 0 rgba(255,255,255,0.2) !important;
            position: relative;
            overflow: hidden;
        }
        .stButton > button::after {
            content: '';
            position: absolute;
            top: 0; left: -100%; width: 50%; height: 100%;
            background: linear-gradient(to right, transparent, rgba(255,255,255,0.2), transparent);
            transform: skewX(-20deg);
            transition: all 0.7s ease;
        }
        .stButton > button:hover::after { left: 150%; }
        .stButton > button:hover {
            transform: translateY(-2px) !important;
            box-shadow: 0 15px 30px -5px rgba(99, 102, 241, 0.5), inset 0 1px 0 rgba(255,255,255,0.3) !important;
            color: white !important;
        }
        
        /* Generated Password Display */
        .pwd-display {
            background: rgba(2, 6, 23, 0.8);
            border: 1px solid rgba(99, 102, 241, 0.3);
            border-radius: 12px;
            padding: 1.5rem;
            margin: 1rem 0;
            text-align: center;
            font-family: 'Space Mono', monospace;
            font-size: 1.6rem;
            font-weight: 700;
            color: #ffffff;
            word-break: break-all;
            box-shadow: inset 0 4px 12px rgba(0,0,0,0.5), 0 0 25px rgba(99, 102, 241, 0.1);
            position: relative;
        }
        .pwd-display::before {
            content: '';
            position: absolute;
            top: -1px; left: 15%; right: 15%; height: 1px;
            background: linear-gradient(90deg, transparent, rgba(165, 180, 252, 0.6), transparent);
        }

        /* Metric Pill */
        .metric-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 100px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-top: 0.5rem;
            margin-bottom: 0.75rem;
        }
        .pill-safe { background: rgba(34, 197, 94, 0.1); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.2); }
        .pill-warn { background: rgba(245, 158, 11, 0.1); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.2); }
        .pill-danger { background: rgba(239, 68, 68, 0.1); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.2); }
        
        /* Features */
        .feature-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 2rem;
            margin-top: 5rem;
            padding-bottom: 4rem;
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
        }
        @media (max-width: 768px) {
            .feature-grid { grid-template-columns: 1fr; }
        }
        .feature-card {
            background: rgba(15, 23, 42, 0.3);
            border: 1px solid rgba(255,255,255,0.04);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s;
        }
        .feature-card:hover {
            background: rgba(30, 41, 59, 0.4);
            border-color: rgba(255,255,255,0.08);
            transform: translateY(-3px);
        }
        .icon-wrap {
            width: 48px; height: 48px;
            border-radius: 12px;
            background: rgba(99, 102, 241, 0.1);
            color: #818cf8;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 1.25rem;
            border: 1px solid rgba(99, 102, 241, 0.2);
        }
        .feature-title { font-weight: 600; color: #fff; margin-bottom: 0.5rem; font-size: 1.1rem;}
        .feature-desc { color: #94a3b8; font-size: 0.9rem; line-height: 1.6;}
    </style>
    """, unsafe_allow_html=True)

# --- UI Layout ---
apply_premium_css()

# Navigation Bar
st.markdown("""
<div class="top-nav">
    <div class="nav-brand">
        <svg viewBox="0 0 24 24"><path d="M12 2C9.243 2 7 4.243 7 7v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V7c0-2.757-2.243-5-5-5zM9 7c0-1.654 1.346-3 3-3s3 1.346 3 3v3H9V7zm7 12H8v-6h8v6z"/></svg>
        PassGen Suite
    </div>
    <div class="nav-links">
        <span>Security Engine</span>
        <span>Enterprise Features</span>
        <span>Documentation</span>
    </div>
</div>
""", unsafe_allow_html=True)

# Hero Section
st.markdown("""
<div class="hero">
    <h1>Generate secure passwords<br>with context-aware AI</h1>
    <p>Eliminate weak credentials. Our engine understands your context and generates mathematically secure, memorable passphrases that resist modern stuffing attacks.</p>
    <div class="trust-badges">
        <div class="badge">🛡️ Zero data storage</div>
        <div class="badge">⚡ Local SHA-1 hashing</div>
        <div class="badge">🌐 k-Anonymity checks</div>
    </div>
</div>
""", unsafe_allow_html=True)

# Main Workspace
col1, col2 = st.columns([1, 1], gap="large")

with col1:
    with st.container(border=True):
        st.markdown("### Generation Parameters")
        context = st.text_input("Context / Purpose", placeholder="e.g., Enterprise AWS root account", help="Guides the AI to produce a memorable thematic phrase. Optional in Local Mode.")
        
        st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
        length = st.slider("Cryptographic Length", min_value=12, max_value=64, value=20)
        
        c_num, c_sym = st.columns(2)
        with c_num:
            use_numbers = st.checkbox("Require Numbers", value=True)
        with c_sym:
            use_symbols = st.checkbox("Require Symbols", value=True)
            
        st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)
        if st.button("Synthesize Payload", use_container_width=True):
            with st.spinner("Synthesizing secure payload..."):
                pwd, mode = password_utils.generate_password(context, length, use_numbers, use_symbols)
                if pwd:
                    st.session_state.last_pwd = pwd
                    st.session_state.last_mode = mode

with col2:
    with st.container(border=True):
        st.markdown("### Output & Analysis")
        
        if not st.session_state.last_pwd:
            st.markdown("""
            <div style='display: flex; flex-direction: column; align-items: center; justify-content: center; height: 260px; opacity: 0.3;'>
                <div style='font-size: 3rem; margin-bottom: 1rem;'>✨</div>
                <p style='font-weight: 500;'>Awaiting generation parameters...</p>
            </div>
            """, unsafe_allow_html=True)
        else:
            pwd = st.session_state.last_pwd
            mode = st.session_state.last_mode
            
            # Display Mode Pill
            if mode == 'ai':
                st.markdown("<div style='text-align: right;'><div class='metric-pill' style='background: rgba(99,102,241,0.1); color:#818cf8; border:1px solid rgba(99,102,241,0.2);'>✨ AI Mode</div></div>", unsafe_allow_html=True)
            else:
                st.markdown("<div style='text-align: right;'><div class='metric-pill pill-safe'>🔒 Local Secure Mode</div></div>", unsafe_allow_html=True)
                
            st.markdown(f"<div class='pwd-display'>{pwd}</div>", unsafe_allow_html=True)
            
            # Use Streamlit's native copy behavior underneath a custom label
            st.code(pwd, language="plaintext")
            
            results = zxcvbn.zxcvbn(pwd)
            score = results['score']
            
            # Layout metrics
            st.markdown("#### Security Insights")
            m1, m2 = st.columns(2)
            
            with m1:
                entropy = int(results.get('guesses_log10', 0) * math.log2(10))
                score_colors = ["#ef4444", "#f59e0b", "#eab308", "#84cc16", "#22c55e"]
                score_labels = ["Critical Risk", "Weak", "Moderate", "Strong", "Military Grade"]
                
                st.markdown(f"**Strength:** <span style='color:{score_colors[score]}'>{score_labels[score]} ({score}/4)</span>", unsafe_allow_html=True)
                st.progress(score / 4)
                st.markdown(f"<span style='font-size: 0.85rem; color: #94a3b8;'>Calculated Entropy: ~{entropy} bits</span>", unsafe_allow_html=True)

            with m2:
                pwned_count = password_utils.check_pwned_api(pwd)
                if pwned_count == -1:
                    st.markdown("<div class='metric-pill pill-warn'>⚠️ Rate Limited</div>", unsafe_allow_html=True)
                elif pwned_count is None:
                    st.markdown("<div class='metric-pill pill-warn'>⚠️ API Offline</div>", unsafe_allow_html=True)
                elif pwned_count > 0:
                    st.markdown(f"<div class='metric-pill pill-danger'>🚨 Exposed in {pwned_count} breaches</div>", unsafe_allow_html=True)
                else:
                    st.markdown("<div class='metric-pill pill-safe'>✅ Zero known exposures</div>", unsafe_allow_html=True)
                
                st.markdown(f"<span style='font-size: 0.85rem; color: #94a3b8;'>Est. Crack Time: {results['crack_times_display']['offline_slow_hashing_1e4_per_second']}</span>", unsafe_allow_html=True)

# Features Section
st.markdown("""
<div class="feature-grid">
    <div class="feature-card">
        <div class="icon-wrap">🧠</div>
        <div class="feature-title">Contextual AI Engine</div>
        <div class="feature-desc">Leverages advanced LLMs to construct memorable passphrases based on your specific use-case, reducing cognitive load without sacrificing security.</div>
    </div>
    <div class="feature-card">
        <div class="icon-wrap">🛡️</div>
        <div class="feature-title">zxcvbn Evaluation</div>
        <div class="feature-desc">Calculates realistic entropy and offline cracking estimates using the industry-standard zxcvbn algorithm developed by Dropbox.</div>
    </div>
    <div class="feature-card">
        <div class="icon-wrap">🔒</div>
        <div class="feature-title">k-Anonymity Verification</div>
        <div class="feature-desc">Checks your password against billions of breached records by securely sending only the first 5 characters of a SHA-1 hash to the HIBP API.</div>
    </div>
</div>
""", unsafe_allow_html=True)
